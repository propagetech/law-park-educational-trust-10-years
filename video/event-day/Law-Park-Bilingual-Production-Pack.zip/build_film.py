"""Build the two 300-second anniversary visual review cuts.

Requires Python 3, Pillow with RAQM, NumPy and FFmpeg with libass/libx264.
All photographs remain documentary source material. No spoken audio is
fabricated. Narration is presented as readable on-screen text in this cut.
"""
from pathlib import Path
import json, math, subprocess, wave, concurrent.futures, shutil, zipfile, hashlib
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parent
ASSETS, OUT, BUILD = ROOT/'assets', ROOT/'output', ROOT/'build'
for d in (OUT, BUILD): d.mkdir(exist_ok=True)
SCENES = json.loads((ROOT/'scenes.json').read_text())
assert sum(s['duration'] for s in SCENES) == 300
W,H,FPS = 1920,1080,24
GREEN = (10,37,34)
IVORY = (247,241,226)
GOLD = (218,188,122)
MUTED = (185,207,195)
DEJAVU = Path('/usr/share/fonts/truetype/dejavu')
FONT_FILES = {
 'en': {'regular':DEJAVU/'DejaVuSans.ttf', 'title':DEJAVU/'DejaVuSerif.ttf'},
 'kn': {'regular':ASSETS/'NotoSansKannada-Regular.ttf', 'title':ASSETS/'NotoSerifKannada-Regular.ttf'}
}
def font(lang,size,title=False):
 return ImageFont.truetype(str(FONT_FILES[lang]['title' if title else 'regular']),size,layout_engine=ImageFont.Layout.RAQM)
def wrap(text,ft,width):
 lines=[]
 for part in text.split('\n'):
  line=''
  for word in part.split():
   candidate=(line+' '+word).strip()
   if ft.getlength(candidate)>width and line:
    lines.append(line); line=word
   else: line=candidate
  lines.append(line)
 return lines
def block(draw,text,lang,xy,width,size,color=IVORY,title=False,center=False,line_factor=1.37):
 ft=font(lang,size,title)
 lines=wrap(text,ft,width)
 x,y=xy
 for line in lines:
  line_font=font('en',size,title) if lang=='kn' and not any('\u0c80'<=c<='\u0cff' for c in line) else ft
  actual_x=x+(width-line_font.getlength(line))/2 if center else x
  draw.text((actual_x,y),line,font=line_font,fill=color,anchor='lt')
  y+=int(size*line_factor)
 return y,lines
def make_background():
 yy,xx=np.mgrid[0:H,0:W]
 glow=np.exp(-(((xx-1450)/1200)**2+((yy-280)/950)**2))
 a=np.empty((H,W,3),dtype=np.uint8)
 for c in range(3): a[:,:,c]=GREEN[c]+glow*[6,19,12][c]
 return Image.fromarray(a)
BASE=make_background()

def compose_scene(lang,i,s):
 im=BASE.copy(); d=ImageDraw.Draw(im)
 # Brand lock-up uses the unmodified original logo on an ivory field.
 logo=Image.open(ASSETS/'logo-copy.png').convert('RGBA')
 logo.thumbnail((62,58),Image.Resampling.LANCZOS)
 d.rectangle((100,54,177,128),fill=IVORY)
 im.paste(logo,(108+(62-logo.width)//2,62+(58-logo.height)//2),logo)
 d.text((200,74),'LAW PARK EDUCATIONAL TRUST',font=font('en',25),fill=IVORY,anchor='lt')
 d.text((1620,74),'2016–2026',font=font('en',25),fill=GOLD,anchor='lt')
 t=s[lang]
 if s['image']:
  y,_=block(d,t['kicker'],lang,(108,217),657,24,GOLD)
  tsize=174 if t['title']=='150' else (83 if lang=='en' else 70)
  # Long titles are broken into full words and remain clear from the hall.
  while len(wrap(t['title'],font(lang,tsize,True),660))>3: tsize-=2
  bottom,lines=block(d,t['title'],lang,(102,312),674,tsize,title=True,line_factor=1.35)
  detail_y=max(618,bottom+34)
  end,_=block(d,t['detail'],lang,(108,detail_y),650,32,MUTED,line_factor=1.5)
  if end>817: raise ValueError(f'Overflow {lang} scene {i+1}: {end}')
  photo=Image.open(ASSETS/s['image']).convert('RGB')
  photo=ImageOps.contain(photo,(958,621),method=Image.Resampling.LANCZOS)
  photo_box=Image.new('RGB',(1000,665),(7,29,27))
  photo_box.paste(photo,((1000-photo.width)//2,(665-photo.height)//2))
  photo_box.save(BUILD/f'photo-{i:02d}.png')
  archive=('ARCHIVE / '+s['archive']) if lang=='en' else (s['archive']+'ರ ನೆನಪು')
  block(d,archive,lang,(830,830),900,22,MUTED)
  preview=im.copy(); preview.paste(photo_box,(820,150))
 else:
  block(d,t['kicker'],lang,(140,238),1640,30,GOLD,center=True)
  block(d,t['title'],lang,(140,345),1640,86 if lang=='en' else 76,title=True,center=True,line_factor=1.35)
  block(d,t['detail'],lang,(170,620),1580,34,MUTED,center=True,line_factor=1.55)
  preview=im.copy()
 # A simple rule separates the reading area from the photography.
 d.line((108,878,1812,878),fill=(64,86,69),width=2)
 im.save(BUILD/f'base-{lang}-{i:02d}.png')
 preview.save(BUILD/f'preview-{lang}-{i:02d}.jpg',quality=90)
 return preview

def timestamp(sec,ass=False):
 if ass:
  h=int(sec//3600);m=int((sec%3600)//60);ss=sec%60
  return f'{h}:{m:02d}:{ss:05.2f}'
 ms=round(sec*1000);h=ms//3600000;m=ms//60000%60;ss=ms//1000%60
 return f'{h:02d}:{m:02d}:{ss:02d},{ms%1000:03d}'

def captions_for(lang,s):
 ft=font(lang,40)
 words=s[lang]['voice'].split()
 count=math.ceil(len(wrap(s[lang]['voice'],ft,1670))/2)
 # Balance words across cues so a final short phrase never flashes briefly.
 while True:
  bounds=[round(j*len(words)/count) for j in range(count+1)]
  pairs=[wrap(' '.join(words[bounds[j]:bounds[j+1]]),ft,1670) for j in range(count)]
  if all(len(p)<=2 for p in pairs):break
  count+=1
 duration=s['duration']-.7
 cues=[];start=.35
 for p in pairs:
  length=duration/len(pairs)
  cues.append((start,start+length,p));start+=length
 return cues

def write_ass(lang,i,s):
 family='DejaVu Sans' if lang=='en' else 'Noto Sans Kannada'
 header=f'''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Default,{family},40,&H00F0F6F7,&H00F0F6F7,&H0022250A,&H0022250A,0,0,0,0,100,100,0,0,1,1.0,0,2,125,125,67,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
 for start,end,lines in captions_for(lang,s):
  txt='\\N'.join(lines)
  header+=f'Dialogue: 0,{timestamp(start,True)},{timestamp(end,True)},Default,,0,0,0,,{{\\fad(120,120)}}{txt}\n'
 path=BUILD/f'captions-{lang}-{i:02d}.ass';path.write_text(header)
 return path

def render_scene(lang,i,s):
 dest=BUILD/f'scene-{lang}-{i:02d}.mp4'
 signature=hashlib.sha256((json.dumps(s,ensure_ascii=False)+lang+Path(__file__).read_text()).encode()).hexdigest()
 stamp=dest.with_suffix('.sha256')
 if dest.exists() and stamp.exists() and stamp.read_text()==signature:return str(dest)
 ass=write_ass(lang,i,s)
 cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-loop','1','-framerate',str(FPS),'-i',str(BUILD/f'base-{lang}-{i:02d}.png')]
 if s['image']:
  cmd+=['-loop','1','-framerate',str(FPS),'-i',str(BUILD/f'photo-{i:02d}.png')]
  n=s['duration']*FPS
  filt=f"[1:v]zoompan=z='1+0.023*on/{n-1}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d=1:s=1000x665:fps={FPS}[p];[0:v][p]overlay=820:150:shortest=1,"
 else: filt='[0:v]'
 filt+=f"subtitles='{ass}':fontsdir='{ASSETS}',fade=t=in:st=0:d=0.32,fade=t=out:st={s['duration']-.32}:d=0.32,format=yuv420p[v]"
 cmd+=['-filter_complex_threads','1','-filter_complex',filt,'-map','[v]','-t',str(s['duration']),'-an','-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-r',str(FPS),'-pix_fmt','yuv420p',str(dest)]
 proc=subprocess.run(cmd,capture_output=True,text=True)
 if proc.returncode: raise RuntimeError(proc.stderr)
 stamp.write_text(signature)
 print(f'Rendered {lang} {i+1:02d}/20',flush=True)
 return str(dest)

def create_music():
 dest=BUILD/'instrumental-guide.wav'
 if dest.exists(): return dest
 sr=32000;n=300*sr
 audio=np.zeros((n,2),np.float32)
 def note(midi,start,dur,amp,pan=0.,pad=False):
  at=int(start*sr); count=min(int(dur*sr),n-at)
  if count<=0:return
  t=np.arange(count,dtype=np.float32)/sr;f=440*2**((midi-69)/12)
  if pad:
   env=np.minimum(t/2.0,1)*np.minimum((dur-t)/2.5,1)
   sig=(np.sin(2*np.pi*f*t)*.7+np.sin(2*np.pi*(f*1.001)*t)*.3)*env*amp
  else:
   env=(1-np.exp(-t*80))*np.exp(-t/1.55)
   sig=(np.sin(2*np.pi*f*t)+.23*np.sin(2*np.pi*f*2*t)*np.exp(-t/1.0)+.08*np.sin(2*np.pi*f*3*t)*np.exp(-t/.5))*env*amp
  audio[at:at+count,0]+=sig*math.sqrt((1-pan)/2)
  audio[at:at+count,1]+=sig*math.sqrt((1+pan)/2)
  if not pad:
   for delay,decay in [(.18,.16),(.37,.1),(.62,.05)]:
    dt=at+int(delay*sr);nn=min(count,n-dt)
    if nn>0:
     audio[dt:dt+nn,0]+=sig[:nn]*decay*math.sqrt((1+pan)/2)
     audio[dt:dt+nn,1]+=sig[:nn]*decay*math.sqrt((1-pan)/2)
 chords=[[50,57,62,66],[47,54,59,62],[43,50,55,59],[45,52,57,61]]
 beat=60/72;bar=beat*8
 for k,start in enumerate(np.arange(0,300,bar)):
  chord=chords[k%4]
  for mid in chord[:3]:note(mid,start,bar+1,.009,pan=-.2,pad=True)
  for j,idx in enumerate([0,2,1,3,2,1]):
   note(chord[idx]+12,start+j*beat,4.2,.045 if j==0 else .034,pan=(-.3 if j%2 else .3))
  if k%2:
   for j,mid in enumerate([chord[2]+24,chord[1]+24,chord[3]+12]):
    note(mid,start+(j+2)*beat,3.3,.02,pan=.15)
 fade=np.minimum(np.arange(n)/(sr*4),1)*np.minimum((n-np.arange(n))/(sr*9),1)
 audio*=fade[:,None]
 peak=np.max(np.abs(audio)); audio=audio/peak*.34
 with wave.open(str(dest),'wb') as w:
  w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes((audio*32767).astype('<i2').tobytes())
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(dest),'-af','loudnorm=I=-23:TP=-3:LRA=8','-ar','48000','-c:a','aac','-b:a','192k',str(OUT/'Instrumental-Guide.m4a')],check=True)
 return dest

def documentation():
 md=['# Law Park Educational Trust · 10-year anniversary film\n',
 '## Delivery status\n',
 'Two 300-second, 1920 × 1080 visual review cuts. Each has full narration as on-screen text in its own language and an original instrumental guide track. **No spoken narration or translated testimonial audio has been generated.** These are review cuts, not completed narrated event masters.\n',
 'The connected AI Voice Generator and Canva apps are confirmed enabled, but their generation and editing actions were not exposed to this session. No voice recording or Canva project is claimed. The original uploaded testimonial compilation remains untouched.\n',
 '## Creative direction\n',
 'Kannada leads for the event audience. Both versions use the same 300-second scene structure, documentary photographs, deep green backgrounds, warm ivory text, gold accents and restrained photo movement. The last 23 seconds contain a direct, dignified invitation to donate or get involved.\n',
 'The emphasis is steady service and concrete outputs. No cumulative beneficiary total, unsupported graduation or employment outcome, invented quotation, health disclosure, payment amount, tax benefit, or artificial testimonial is included.\n',
 '## Narrator direction\n',
 'Use one warm, unhurried adult narrator per language. Kannada should sound like a person speaking to families in the hall. English should use natural Indian pronunciation. Allow breathing room around place names and counts. Do not imitate the people in the uploaded video. Timings below are scene targets; once voices are recorded, adjust pauses and shot durations to preserve natural delivery and a total running time of about five minutes.\n',
 'Pronunciation: Chikkaballapura / ಚಿಕ್ಕಬಳ್ಳಾಪುರ; Male Mahadeshwara Betta / ಮಲೆ ಮಹದೇಶ್ವರ ಬೆಟ್ಟ; H.D. Kote / ಎಚ್.ಡಿ. ಕೋಟೆ; Nisarga Foundation / ನಿಸರ್ಗ ಫೌಂಡೇಶನ್. The trust’s Kannada name is transliterated as ಲಾ ಪಾರ್ಕ್ ಎಜುಕೇಷನಲ್ ಟ್ರಸ್ಟ್.\n',
 '## Sources and editorial checks\n',
 '- [Trust anniversary website](https://journey.lawparkeducationaltrust.org/#journey), inspected 11 September 2026. The dates, specific event counts, library locations and Nisarga Foundation association follow this timeline.\n',
 '- [Trust process](https://journey.lawparkeducationaltrust.org/#process): nominations, family meetings, tuition support up to 75%, family contribution and payment directly to the school.\n',
 '- The two-person Bengaluru journey in 2016 and the preferred narrative emphasis come from the user’s brief.\n',
 '- Images are the trust’s public archive files. Their year labels follow the website galleries. Where a gallery covers multiple locations, a photograph illustrates that year’s work; it does not independently prove the bag count or the precise school shown. Confirm individual event-photo captions with the organisers before the event master.\n',
 '- The website displays conflicting cumulative student and district totals. None is used. Success is described through delivered support, not unverified long-term outcomes.\n',
 '- The closing email is shown on the trust website. The invitation directs viewers to the team, so no unconfirmed QR code, UPI recipient or donation amount enters the film. An approved event donation QR can be added to the closing scene.\n',
 '## English and Kannada narration\n']
 elapsed=0
 srt={'en':[],'kn':[]};srt_count={'en':0,'kn':0}
 for i,s in enumerate(SCENES):
  end=elapsed+s['duration']
  md.append(f"### {i+1:02d} · {timestamp(elapsed)[:8]}–{timestamp(end)[:8]}\n")
  md.append('**English**\n\n'+s['en']['voice']+'\n')
  md.append('**ಕನ್ನಡ**\n\n'+s['kn']['voice']+'\n')
  if s['image']:md.append(f"Archive image: [{s['image']}](https://journey.lawparkeducationaltrust.org/images/{s['image']})\n")
  for lang in ['en','kn']:
   for a,b,lines in captions_for(lang,s):
    srt_count[lang]+=1
    srt[lang].append(f"{srt_count[lang]}\n{timestamp(elapsed+a)} --> {timestamp(elapsed+b)}\n"+'\n'.join(lines)+'\n')
  elapsed=end
 for lang in ['en','kn']:
  (OUT/f'Narration-{lang}.txt').write_text('\n\n'.join(s[lang]['voice'] for s in SCENES))
  (OUT/f'Captions-{lang}.srt').write_text('\n'.join(srt[lang]))
 md += ['## Completion of the narrated masters\n',
 'Record the supplied narration in both languages, review Kannada wording and pronunciation with a fluent reader, then mix each narration above the instrumental bed. Listen on the event sound system and check every title from the back of the hall. An event organiser should confirm photo captions and the preferred donation contact before the master export.\n',
 '## Editable files\n',
 '`scenes.json` holds scene duration, titles, captions and narration. `build_film.py` rebuilds the visual cuts. `assets/` contains the source photographs, logo and Kannada fonts. `Captions-en.srt` and `Captions-kn.srt` are timed reading guides for these cuts and can be revised to match recorded voices. They are not transcripts of the original uploaded film.\n',
 'The original instrumental guide is generated locally from simple additive tones. It contains no sampled commercial recording. It can be replaced by an event-approved score during the final mix.\n']
 (OUT/'Law-Park-Bilingual-Script-and-Edit-Notes.md').write_text('\n'.join(md))
 print('English words',sum(len(s['en']['voice'].split()) for s in SCENES),'Kannada words',sum(len(s['kn']['voice'].split()) for s in SCENES),flush=True)

def assemble(lang):
 concat=BUILD/f'concat-{lang}.txt'
 concat.write_text('\n'.join("file '"+str(BUILD/f'scene-{lang}-{i:02d}.mp4')+"'" for i in range(len(SCENES))))
 name='Kannada' if lang=='kn' else 'English'
 dest=OUT/f'Law-Park-10-Years-{name}-Visual-Review.mp4'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(concat),'-i',str(OUT/'Instrumental-Guide.m4a'),'-map','0:v:0','-map','1:a:0','-c','copy','-t','300','-movflags','+faststart','-metadata',f'title=Law Park Educational Trust - 10 Years - {name} Visual Review','-metadata','comment=Visual review with on-screen narration and original instrumental guide. Spoken narration pending.',str(dest)],check=True)
 print('Completed',dest.name,flush=True)

def pack():
 with zipfile.ZipFile(OUT/'Law-Park-Bilingual-Production-Pack.zip','w',zipfile.ZIP_DEFLATED) as z:
  for p in [ROOT/'build_film.py',ROOT/'scenes.json']+list(ASSETS.iterdir())+list(OUT.glob('*.txt'))+list(OUT.glob('*.srt'))+list(OUT.glob('*.md'))+[OUT/'Instrumental-Guide.m4a']:
   z.write(p,p.relative_to(ROOT))

if __name__=='__main__':
 import sys
 for lang in ['kn','en']:
  for i,s in enumerate(SCENES):compose_scene(lang,i,s)
 documentation()
 if '--prepare-only' not in sys.argv:
  create_music()
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   futs=[pool.submit(render_scene,lang,i,s) for lang in ['kn','en'] for i,s in enumerate(SCENES)]
   for f in concurrent.futures.as_completed(futs):f.result()
  assemble('kn');assemble('en');pack()
