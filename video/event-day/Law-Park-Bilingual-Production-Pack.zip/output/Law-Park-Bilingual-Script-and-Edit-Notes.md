# Law Park Educational Trust · 10-year anniversary film

## Delivery status

Two 300-second, 1920 × 1080 visual review cuts. Each has full narration as on-screen text in its own language and an original instrumental guide track. **No spoken narration or translated testimonial audio has been generated.** These are review cuts, not completed narrated event masters.

The connected AI Voice Generator and Canva apps are confirmed enabled, but their generation and editing actions were not exposed to this session. No voice recording or Canva project is claimed. The original uploaded testimonial compilation remains untouched.

## Creative direction

Kannada leads for the event audience. Both versions use the same 300-second scene structure, documentary photographs, deep green backgrounds, warm ivory text, gold accents and restrained photo movement. The last 23 seconds contain a direct, dignified invitation to donate or get involved.

The emphasis is steady service and concrete outputs. No cumulative beneficiary total, unsupported graduation or employment outcome, invented quotation, health disclosure, payment amount, tax benefit, or artificial testimonial is included.

## Narrator direction

Use one warm, unhurried adult narrator per language. Kannada should sound like a person speaking to families in the hall. English should use natural Indian pronunciation. Allow breathing room around place names and counts. Do not imitate the people in the uploaded video. Timings below are scene targets; once voices are recorded, adjust pauses and shot durations to preserve natural delivery and a total running time of about five minutes.

Pronunciation: Chikkaballapura / ಚಿಕ್ಕಬಳ್ಳಾಪುರ; Male Mahadeshwara Betta / ಮಲೆ ಮಹದೇಶ್ವರ ಬೆಟ್ಟ; H.D. Kote / ಎಚ್.ಡಿ. ಕೋಟೆ; Nisarga Foundation / ನಿಸರ್ಗ ಫೌಂಡೇಶನ್. The trust’s Kannada name is transliterated as ಲಾ ಪಾರ್ಕ್ ಎಜುಕೇಷನಲ್ ಟ್ರಸ್ಟ್.

## Sources and editorial checks

- [Trust anniversary website](https://journey.lawparkeducationaltrust.org/#journey), inspected 11 September 2026. The dates, specific event counts, library locations and Nisarga Foundation association follow this timeline.

- [Trust process](https://journey.lawparkeducationaltrust.org/#process): nominations, family meetings, tuition support up to 75%, family contribution and payment directly to the school.

- The two-person Bengaluru journey in 2016 and the preferred narrative emphasis come from the user’s brief.

- Images are the trust’s public archive files. Their year labels follow the website galleries. Where a gallery covers multiple locations, a photograph illustrates that year’s work; it does not independently prove the bag count or the precise school shown. Confirm individual event-photo captions with the organisers before the event master.

- The website displays conflicting cumulative student and district totals. None is used. Success is described through delivered support, not unverified long-term outcomes.

- The closing email is shown on the trust website. The invitation directs viewers to the team, so no unconfirmed QR code, UPI recipient or donation amount enters the film. An approved event donation QR can be added to the closing scene.

## English and Kannada narration

### 01 · 00:00:00–00:00:12

**English**

Welcome to ten years of Law Park Educational Trust. Tonight, we celebrate a simple commitment: being there for a child’s education, year after year.

**ಕನ್ನಡ**

ಲಾ ಪಾರ್ಕ್ ಎಜುಕೇಷನಲ್ ಟ್ರಸ್ಟ್‌ನ ಹತ್ತನೇ ವರ್ಷದ ಸಂಭ್ರಮಕ್ಕೆ ಸ್ವಾಗತ. ಮಕ್ಕಳ ಶಿಕ್ಷಣಕ್ಕೆ ವರ್ಷದಿಂದ ವರ್ಷಕ್ಕೆ ಜೊತೆಯಾಗಿ ನಿಂತ ಈ ಪಯಣವನ್ನು ಇಂದು ನಾವೆಲ್ಲರೂ ಒಟ್ಟಾಗಿ ಸಂಭ್ರಮಿಸೋಣ.

Archive image: [slide_27_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_27_Picture_1_00.webp)

### 02 · 00:00:12–00:00:28

**English**

To the children and their parents, our volunteers, trustees and donors, and our chief guest: welcome. Each of you has a place in this story. It is a journey we share.

**ಕನ್ನಡ**

ಇಲ್ಲಿರುವ ಮಕ್ಕಳಿಗೆ, ಪೋಷಕರಿಗೆ, ಸ್ವಯಂಸೇವಕರಿಗೆ, ಟ್ರಸ್ಟಿಗಳಿಗೆ, ದಾನಿಗಳಿಗೆ ಮತ್ತು ನಮ್ಮ ಮುಖ್ಯ ಅತಿಥಿಗಳಿಗೆ ಆತ್ಮೀಯ ಸ್ವಾಗತ. ಈ ಪಯಣದಲ್ಲಿ ನಿಮ್ಮೆಲ್ಲರಿಗೂ ಒಂದು ಸ್ಥಾನವಿದೆ. ಈ ಸಂಭ್ರಮ ನಮ್ಮೆಲ್ಲರದು.

Archive image: [2017.webp](https://journey.lawparkeducationaltrust.org/images/2017.webp)

### 03 · 00:00:28–00:00:48

**English**

In 2016, two people travelled from Bengaluru to Chickaballapur and paid one child’s school fee. That first scholarship gave this journey its beginning. A need was heard, a family was met, and someone followed through.

**ಕನ್ನಡ**

ಎರಡು ಸಾವಿರದ ಹದಿನಾರರಲ್ಲಿ, ಬೆಂಗಳೂರಿನಿಂದ ಇಬ್ಬರು ಚಿಕ್ಕಬಳ್ಳಾಪುರಕ್ಕೆ ತೆರಳಿ, ಒಂದು ಮಗುವಿನ ಶಾಲಾ ಶುಲ್ಕವನ್ನು ಪಾವತಿಸಿದರು. ಆ ಮೊದಲ ವಿದ್ಯಾರ್ಥಿವೇತನವೇ ಈ ಪಯಣದ ಆರಂಭ. ಒಂದು ಅಗತ್ಯವನ್ನು ಆಲಿಸಿ, ಕುಟುಂಬವನ್ನು ಭೇಟಿಯಾಗಿ, ನೀಡಿದ ಮಾತನ್ನು ಕಾರ್ಯರೂಪಕ್ಕೆ ತಂದರು.

Archive image: [slide_03_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_03_Picture_1_00.webp)

### 04 · 00:00:48–00:01:04

**English**

That early school visit also brought steel plates and tumblers to one hundred and fifty children in Chickaballapur. Everyday things, with an everyday purpose. This is how we want to remember our work: clearly, and specifically.

**ಕನ್ನಡ**

ಆ ಮೊದಲ ಶಾಲಾ ಭೇಟಿಯ ಸಂದರ್ಭದಲ್ಲಿ ಚಿಕ್ಕಬಳ್ಳಾಪುರದ ನೂರೈವತ್ತು ಮಕ್ಕಳಿಗೆ ಉಕ್ಕಿನ ತಟ್ಟೆಗಳು ಮತ್ತು ಲೋಟಗಳನ್ನು ನೀಡಿದೆವು. ದಿನನಿತ್ಯ ಬಳಸುವ ವಸ್ತುಗಳ ಮೂಲಕವೂ ಮಕ್ಕಳಿಗೆ ನೆರವಾಗಬಹುದು. ನಮ್ಮ ಕೆಲಸವನ್ನು ಇಂತಹ ಸ್ಪಷ್ಟ ನೆನಪುಗಳೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಲು ಬಯಸುತ್ತೇವೆ.

Archive image: [steel-plate-and-glass-distributed-to-these-children.webp](https://journey.lawparkeducationaltrust.org/images/steel-plate-and-glass-distributed-to-these-children.webp)

### 05 · 00:01:04–00:01:18

**English**

The work still begins when someone puts a child’s name forward. A school principal, a neighbour, or a well-wisher tells us about a child who needs support to continue learning.

**ಕನ್ನಡ**

ಇಂದಿಗೂ ನಮ್ಮ ಕೆಲಸ ಆರಂಭವಾಗುವುದು ಯಾರಾದರೂ ಒಂದು ಮಗುವಿನ ಬಗ್ಗೆ ತಿಳಿಸಿದಾಗಲೇ. ಶಾಲಾ ಮುಖ್ಯಸ್ಥರು, ಊರಿನವರು ಅಥವಾ ಹಿತೈಷಿಗಳು, ಓದು ಮುಂದುವರಿಸಲು ನೆರವು ಬೇಕಿರುವ ಮಗುವನ್ನು ನಮ್ಮ ಗಮನಕ್ಕೆ ತರುತ್ತಾರೆ.

Archive image: [slide_04_Picture_4_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_04_Picture_4_00.webp)

### 06 · 00:01:18–00:01:34

**English**

Then the team travels out. We sit with the child and the family, listen to their circumstances, and understand the support they need. A conversation gives meaning to a name on a list.

**ಕನ್ನಡ**

ನಂತರ ನಮ್ಮ ತಂಡ ಅಲ್ಲಿಗೆ ತೆರಳುತ್ತದೆ. ಮಗು ಮತ್ತು ಕುಟುಂಬದವರೊಂದಿಗೆ ಕುಳಿತು ಮಾತನಾಡಿ, ಅವರ ಪರಿಸ್ಥಿತಿಯನ್ನೂ ಅಗತ್ಯವನ್ನೂ ಅರ್ಥಮಾಡಿಕೊಳ್ಳುತ್ತದೆ. ಪಟ್ಟಿಯಲ್ಲಿರುವ ಒಂದು ಹೆಸರಿನ ಹಿಂದೆ ಇರುವ ಕುಟುಂಬವನ್ನು ಈ ಭೇಟಿಯ ಮೂಲಕ ತಿಳಿದುಕೊಳ್ಳುತ್ತೇವೆ.

Archive image: [slide_14_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_14_Picture_1_00.webp)

### 07 · 00:01:34–00:01:52

**English**

When a child receives scholarship support, the trust pays up to seventy-five per cent of the tuition fee. The family contributes the remaining share. Each arrangement begins with understanding that child’s circumstances and educational needs.

**ಕನ್ನಡ**

ವಿದ್ಯಾರ್ಥಿವೇತನದ ನೆರವು ಪಡೆಯುವ ಮಗುವಿನ ಬೋಧನಾ ಶುಲ್ಕದ ಶೇಕಡಾ ಎಪ್ಪತ್ತೈದರಷ್ಟು ಮೊತ್ತದವರೆಗೆ ಟ್ರಸ್ಟ್ ಪಾವತಿಸುತ್ತದೆ. ಉಳಿದ ಪಾಲನ್ನು ಕುಟುಂಬ ಭರಿಸುತ್ತದೆ. ಮಗುವಿನ ಪರಿಸ್ಥಿತಿ ಮತ್ತು ಶೈಕ್ಷಣಿಕ ಅಗತ್ಯಗಳನ್ನು ಅರ್ಥಮಾಡಿಕೊಂಡು ಈ ನೆರವನ್ನು ನೀಡಲಾಗುತ್ತದೆ.

Archive image: [slide_11_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_11_Picture_1_00.webp)

### 08 · 00:01:52–00:02:04

**English**

The trust pays the fees directly to the school. It is a straightforward part of the process, connecting the support to the education it is meant for.

**ಕನ್ನಡ**

ಟ್ರಸ್ಟ್ ಶುಲ್ಕವನ್ನು ನೇರವಾಗಿ ಶಾಲೆಗೆ ಪಾವತಿಸುತ್ತದೆ. ನೀಡುವ ನೆರವು ಉದ್ದೇಶಿತ ಶಿಕ್ಷಣಕ್ಕೆ ತಲುಪುವಂತೆ ಮಾಡುವ ಸರಳ, ಸ್ಪಷ್ಟ ಕ್ರಮ ಇದು. ಮೊದಲಿನಿಂದಲೂ ಈ ವಿಧಾನ ನಮ್ಮ ಕೆಲಸದ ಮುಖ್ಯ ಭಾಗವಾಗಿದೆ.

Archive image: [slide_21_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_21_Picture_1_00.webp)

### 09 · 00:02:04–00:02:22

**English**

School fees are one part of learning. In 2022, donated books helped establish libraries in rural schools in Mandya and Kolar. Stories and study materials found a place where children could reach for them.

**ಕನ್ನಡ**

ಕಲಿಕೆಗೆ ಶುಲ್ಕದ ನೆರವಿನ ಜೊತೆಗೆ ಪುಸ್ತಕಗಳೂ ಬೇಕು. ಎರಡು ಸಾವಿರದ ಇಪ್ಪತ್ತೆರಡರಲ್ಲಿ, ದಾನವಾಗಿ ಬಂದ ಪುಸ್ತಕಗಳಿಂದ ಮಂಡ್ಯ ಮತ್ತು ಕೋಲಾರದ ಗ್ರಾಮೀಣ ಶಾಲೆಗಳಲ್ಲಿ ಗ್ರಂಥಾಲಯಗಳನ್ನು ಸ್ಥಾಪಿಸಲು ನೆರವಾದೆವು. ಕಥೆಗಳು ಮತ್ತು ಕಲಿಕಾ ಪುಸ್ತಕಗಳು ಮಕ್ಕಳಿಗೆ ಹತ್ತಿರವಾದವು.

Archive image: [slide_09_Picture_3_01.webp](https://journey.lawparkeducationaltrust.org/images/slide_09_Picture_3_01.webp)

### 10 · 00:02:22–00:02:40

**English**

For students in standards nine and ten, the next step brings important questions. Career guidance gives them space to explore further studies and possible paths. Listening to their interests is part of taking their future seriously.

**ಕನ್ನಡ**

ಒಂಬತ್ತು ಮತ್ತು ಹತ್ತನೇ ತರಗತಿಯ ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಮುಂದಿನ ವಿದ್ಯಾಭ್ಯಾಸದ ಬಗ್ಗೆ ಹಲವು ಪ್ರಶ್ನೆಗಳಿರುತ್ತವೆ. ಮಾರ್ಗದರ್ಶನದ ಮೂಲಕ ಅವರು ವಿವಿಧ ಅವಕಾಶಗಳನ್ನು ತಿಳಿದುಕೊಳ್ಳಲು ನೆರವಾಗುತ್ತೇವೆ. ಅವರ ಆಸಕ್ತಿಯನ್ನು ಆಲಿಸುವುದೂ, ಅವರ ಭವಿಷ್ಯಕ್ಕೆ ಬೆಂಬಲ ನೀಡುವ ಒಂದು ಮಾರ್ಗ.

Archive image: [slide_11_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_11_Picture_1_00.webp)

### 11 · 00:02:40–00:02:52

**English**

There is work before every school visit, too. Supplies are gathered, bags are packed, and people make time. Small preparations help turn an intention into something a child can use.

**ಕನ್ನಡ**

ಪ್ರತಿ ಶಾಲಾ ಭೇಟಿಗೂ ಮೊದಲು ಸಿದ್ಧತೆಗಳಿರುತ್ತವೆ. ಸಾಮಗ್ರಿಗಳನ್ನು ಒಟ್ಟುಗೂಡಿಸಿ, ಚೀಲಗಳನ್ನು ಸಿದ್ಧಪಡಿಸಿ, ಸಮಯ ಮೀಸಲಿಡುತ್ತೇವೆ. ನೆರವಾಗಬೇಕೆಂಬ ಉದ್ದೇಶ ಹೀಗೆ ಮಗುವಿಗೆ ಬಳಕೆಯಾಗುವ ವಸ್ತುವಾಗಿ ತಲುಪುತ್ತದೆ.

Archive image: [slide_18_Picture_2_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_18_Picture_2_00.webp)

### 12 · 00:02:52–00:03:10

**English**

At the start of the 2024–25 academic year, the trust visited schools in MM Hills and distributed two hundred school bags, along with notebooks and stationery. A specific visit, a specific place, and support children could carry home.

**ಕನ್ನಡ**

ಎರಡು ಸಾವಿರದ ಇಪ್ಪತ್ತನಾಲ್ಕು–ಇಪ್ಪತ್ತೈದರ ಶೈಕ್ಷಣಿಕ ವರ್ಷದ ಆರಂಭದಲ್ಲಿ, ಮಲೆ ಮಹದೇಶ್ವರ ಬೆಟ್ಟದ ಶಾಲೆಗಳಿಗೆ ಭೇಟಿ ನೀಡಿದೆವು. ಇನ್ನೂರು ಶಾಲಾ ಚೀಲಗಳೊಂದಿಗೆ ನೋಟ್‌ಪುಸ್ತಕಗಳು ಮತ್ತು ಲೇಖನ ಸಾಮಗ್ರಿಗಳನ್ನು ವಿತರಿಸಿದೆವು. ಮಕ್ಕಳ ಕೈಗೆ ತಲುಪಿದ ಈ ನೆರವು ನಮ್ಮ ಪಯಣದ ಒಂದು ಸ್ಪಷ್ಟ ನೆನಪು.

Archive image: [slide_19_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_19_Picture_1_00.webp)

### 13 · 00:03:10–00:03:28

**English**

In 2025, the work continued in H.D. Kote. With Nisarga Foundation, the trust distributed three hundred school bags, notebooks and stationery. Partnership helped people turn shared concern for education into a practical response.

**ಕನ್ನಡ**

ಎರಡು ಸಾವಿರದ ಇಪ್ಪತ್ತೈದರಲ್ಲಿ, ಎಚ್.ಡಿ. ಕೋಟೆಯಲ್ಲಿ ಈ ಕೆಲಸ ಮುಂದುವರಿಯಿತು. ನಿಸರ್ಗ ಫೌಂಡೇಶನ್ ಸಹಯೋಗದಲ್ಲಿ ಮುನ್ನೂರು ಶಾಲಾ ಚೀಲಗಳು, ನೋಟ್‌ಪುಸ್ತಕಗಳು ಮತ್ತು ಲೇಖನ ಸಾಮಗ್ರಿಗಳನ್ನು ವಿತರಿಸಿದೆವು. ಶಿಕ್ಷಣದ ಬಗ್ಗೆ ಇರುವ ಕಾಳಜಿ, ಸಹಯೋಗದ ಮೂಲಕ ನೆರವಿನ ರೂಪ ಪಡೆದಿತು.

Archive image: [slide_24_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_24_Picture_1_00.webp)

### 14 · 00:03:28–00:03:40

**English**

A bag, a notebook, a pen: each has a place in a school day. Supporting education means paying attention to these ordinary, useful things as well.

**ಕನ್ನಡ**

ಒಂದು ಚೀಲ, ನೋಟ್‌ಪುಸ್ತಕ, ಪೆನ್ನು. ಶಾಲೆಯ ದಿನಚರಿಯಲ್ಲಿ ಪ್ರತಿಯೊಂದಕ್ಕೂ ಪಾತ್ರವಿದೆ. ಶಿಕ್ಷಣಕ್ಕೆ ನೆರವಾಗುವುದು ಎಂದರೆ, ಮಕ್ಕಳಿಗೆ ಪ್ರತಿದಿನ ಬೇಕಾಗುವ ಇಂತಹ ಸರಳ ವಸ್ತುಗಳತ್ತಲೂ ಗಮನ ನೀಡುವುದು.

Archive image: [slide_19_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_19_Picture_1_00.webp)

### 15 · 00:03:40–00:03:56

**English**

Learning also happens through games, cultural activities and conversation. Children need room to ask questions, share what they enjoy, and express themselves. Their curiosity and their own voices belong at the centre of this work.

**ಕನ್ನಡ**

ಆಟಗಳು, ಸಾಂಸ್ಕೃತಿಕ ಚಟುವಟಿಕೆಗಳು ಮತ್ತು ಮಾತುಕತೆಯ ಮೂಲಕವೂ ಕಲಿಕೆ ನಡೆಯುತ್ತದೆ. ಪ್ರಶ್ನೆ ಕೇಳಲು, ತಮಗೆ ಇಷ್ಟವಾದುದನ್ನು ಹಂಚಿಕೊಳ್ಳಲು, ತಮ್ಮ ಪ್ರತಿಭೆಯನ್ನು ತೋರಿಸಲು ಮಕ್ಕಳಿಗೆ ಅವಕಾಶ ಬೇಕು. ಅವರ ಕುತೂಹಲ ಮತ್ತು ಅವರ ಮಾತುಗಳಿಗೆ ನಮ್ಮ ಕೆಲಸದಲ್ಲಿ ಮುಖ್ಯ ಸ್ಥಾನವಿದೆ.

Archive image: [slide_27_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_27_Picture_1_00.webp)

### 16 · 00:03:56–00:04:10

**English**

For us, success is visible in the support delivered: school fees paid, books made available, and time spent listening. These are the everyday commitments that give ten years their meaning.

**ಕನ್ನಡ**

ನಮ್ಮ ಸಾಧನೆ ತಲುಪಿಸಿದ ನೆರವಿನಲ್ಲಿ ಕಾಣುತ್ತದೆ. ಪಾವತಿಸಿದ ಶಾಲಾ ಶುಲ್ಕ, ಮಕ್ಕಳಿಗೆ ದೊರೆತ ಪುಸ್ತಕಗಳು, ಅವರ ಮಾತು ಕೇಳಲು ಮೀಸಲಿಟ್ಟ ಸಮಯ. ಇಂತಹ ದಿನನಿತ್ಯದ ಬದ್ಧತೆಗಳೇ ಈ ಹತ್ತು ವರ್ಷಗಳಿಗೆ ಅರ್ಥ ನೀಡುತ್ತವೆ.

Archive image: [slide_09_Picture_3_01.webp](https://journey.lawparkeducationaltrust.org/images/slide_09_Picture_3_01.webp)

### 17 · 00:04:10–00:04:27

**English**

Thank you to the families who place their trust in us, the volunteers who give their time, and the trustees and donors who keep the work going. And to the children: this celebration is yours, too.

**ಕನ್ನಡ**

ನಮ್ಮ ಮೇಲೆ ನಂಬಿಕೆ ಇಟ್ಟ ಕುಟುಂಬಗಳಿಗೆ, ಸಮಯ ನೀಡಿದ ಸ್ವಯಂಸೇವಕರಿಗೆ, ಕೆಲಸವನ್ನು ಮುಂದುವರಿಸಲು ನೆರವಾದ ಟ್ರಸ್ಟಿಗಳು ಮತ್ತು ದಾನಿಗಳಿಗೆ ಧನ್ಯವಾದಗಳು. ಮಕ್ಕಳೇ, ಈ ಸಂಭ್ರಮ ನಿಮ್ಮದೂ ಹೌದು. ಇಂದು ನಿಮ್ಮೊಂದಿಗೆ ಇರುವುದೇ ನಮಗೆ ಸಂತೋಷ.

Archive image: [slide_14_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_14_Picture_1_00.webp)

### 18 · 00:04:27–00:04:37

**English**

As we enter the next ten years, that first commitment remains: understand the child, meet the family, and support the education.

**ಕನ್ನಡ**

ಮುಂದಿನ ಹತ್ತು ವರ್ಷಗಳತ್ತ ಸಾಗುವಾಗಲೂ, ನಮ್ಮ ಬದ್ಧತೆ ಅದೇ. ಮಗುವನ್ನು ಅರ್ಥಮಾಡಿಕೊಳ್ಳುವುದು, ಕುಟುಂಬವನ್ನು ಭೇಟಿಯಾಗುವುದು, ಶಿಕ್ಷಣಕ್ಕೆ ಬೆಂಬಲ ನೀಡುವುದು.

Archive image: [slide_27_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_27_Picture_1_00.webp)

### 19 · 00:04:37–00:04:50

**English**

If you can, please donate to support this work. You can also give your time, contribute books or school supplies, or introduce a child who needs educational support.

**ಕನ್ನಡ**

ನಿಮಗೆ ಸಾಧ್ಯವಾದರೆ, ಈ ಸೇವೆಗೆ ದೇಣಿಗೆ ನೀಡಿ. ಸ್ವಯಂಸೇವಕರಾಗಿ ಸಮಯ ನೀಡಬಹುದು, ಪುಸ್ತಕ ಅಥವಾ ಶಾಲಾ ಸಾಮಗ್ರಿಗಳನ್ನು ಕೊಡುಗೆಯಾಗಿ ನೀಡಬಹುದು. ಶಿಕ್ಷಣಕ್ಕೆ ನೆರವು ಬೇಕಿರುವ ಮಗುವನ್ನು ನಮಗೆ ಪರಿಚಯಿಸಬಹುದು.

Archive image: [slide_21_Picture_1_00.webp](https://journey.lawparkeducationaltrust.org/images/slide_21_Picture_1_00.webp)

### 20 · 00:04:50–00:05:00

**English**

Please speak with the trust team to contribute or get involved. Thank you for being here. Let us write the next chapter together.

**ಕನ್ನಡ**

ದೇಣಿಗೆ ನೀಡಲು ಅಥವಾ ಈ ಸೇವೆಯಲ್ಲಿ ಜೊತೆಯಾಗಲು ಟ್ರಸ್ಟ್ ತಂಡವನ್ನು ಸಂಪರ್ಕಿಸಿ. ನಮ್ಮೊಂದಿಗೆ ಇರುವ ನಿಮಗೆ ಧನ್ಯವಾದಗಳು. ಮುಂದಿನ ಅಧ್ಯಾಯವನ್ನು ಒಟ್ಟಾಗಿ ಬರೆಯೋಣ.

## Completion of the narrated masters

Record the supplied narration in both languages, review Kannada wording and pronunciation with a fluent reader, then mix each narration above the instrumental bed. Listen on the event sound system and check every title from the back of the hall. An event organiser should confirm photo captions and the preferred donation contact before the master export.

## Editable files

`scenes.json` holds scene duration, titles, captions and narration. `build_film.py` rebuilds the visual cuts. `assets/` contains the source photographs, logo and Kannada fonts. `Captions-en.srt` and `Captions-kn.srt` are timed reading guides for these cuts and can be revised to match recorded voices. They are not transcripts of the original uploaded film.

The original instrumental guide is generated locally from simple additive tones. It contains no sampled commercial recording. It can be replaced by an event-approved score during the final mix.
